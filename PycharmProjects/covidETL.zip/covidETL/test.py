import datetime


today = datetime.date.today()
today = int(today.strftime('%Y%m%d'))
print(today)